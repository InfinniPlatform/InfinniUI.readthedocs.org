function startAction(context, args) {
    console.log( 'startAction ', args );
};

function startAction1(context, args) {
    console.log( 'startAction1 ', args );
};

function startAction2(context, args) {
    console.log( 'startAction2 ', args );
};

function startAction3(context, args) {
    console.log( 'startAction3 ', args );
};

function startAction4(context, args) {
    console.log( 'startAction4 ', args );
};

function startAction5(context, args) {
    console.log( 'startAction5 ', args );
};

function startAction6(context, args) {
    console.log( 'startAction6 ', args );
};

function startAction7(context, args) {
    console.log( 'startAction7 ', args );
};
